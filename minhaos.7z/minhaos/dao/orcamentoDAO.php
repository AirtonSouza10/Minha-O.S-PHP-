<?php

require_once 'conexao.php';


class OrcamentoDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function getAllOrcamentos() {
        try {
            $sql = "SELECT o.id,c.nome as cliente,f.nome as funcionario,DATE_FORMAT(o.datavenda,'%d/%m/%Y') AS datavenda,DATE_FORMAT(o.dataentrega,'%d/%m/%Y') AS dataentrega, o.situacao,o.os FROM orcamento as o,cliente as c,funcionario as f  WHERE o.cliente_id=c.id AND o.funcionario_id=f.id ORDER BY o.datavenda DESC LIMIT 100";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $orcamento = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $orcamento;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function salvarOrcamento(OrcamentoDTO $orcamentoDTO) {
        try {
            $sql = "INSERT INTO orcamento (cliente_id,funcionario_id,produto,datavenda,dataentrega,situacao,os,obs) 
                    VALUES (?,?,?,?,?,?,?,?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $orcamentoDTO->getCliente_id());
            $stmt->bindValue(2, $orcamentoDTO->getFuncionario_id());
            $stmt->bindValue(3, $orcamentoDTO->getProduto());
            $stmt->bindValue(4, $orcamentoDTO->getDatavenda());
            $stmt->bindValue(5, $orcamentoDTO->getDataentrega());
            $stmt->bindValue(6, $orcamentoDTO->getSituacao());
            $stmt->bindValue(7, $orcamentoDTO->getOs());
            $stmt->bindValue(8, $orcamentoDTO->getObs());
            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirOrcamento($id) {
        try {
            $sql = "DELETE FROM orcamento 
                   WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function updateOrcamentoById(OrcamentoDTO $orcamentoDTO) {
        try {
            $sql = "UPDATE orcamento SET   produto=?,
                                           dataentrega=?,
                                           situacao=?,
                                           os=?,
                                           obs=?
                    WHERE id= ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $orcamentoDTO->getProduto());
            $stmt->bindValue(2, $orcamentoDTO->getDataentrega());
            $stmt->bindValue(3, $orcamentoDTO->getSituacao());
            $stmt->bindValue(4, $orcamentoDTO->getOs());
            $stmt->bindValue(5, $orcamentoDTO->getObs());            
            $stmt->bindValue(6, $orcamentoDTO->getId());
            $stmt->execute();
            
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function getOrcamentoById($id) {
        try {
            $sql = "SELECT id,produto,dataentrega,situacao,os,obs FROM orcamento WHERE id = ? ";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $orcamento = $stmt->fetch(PDO::FETCH_ASSOC);
            return $orcamento;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }    

    public function getOrcamentoByIdentificacao($user) {
        try {
            $sql = "SELECT c.identificacao as cpf,f.nome as funcionario,o.produto,DATE_FORMAT(o.datavenda,'%d/%m/%Y') AS datavenda,DATE_FORMAT(o.dataentrega,'%d/%m/%Y') AS dataentrega,o.situacao,o.os,o.obs FROM orcamento as o,cliente as c,funcionario as f WHERE c.identificacao = ? AND o.cliente_id=c.id AND o.funcionario_id=f.id ORDER BY o.dataentrega desc";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $user);
            $stmt->execute();
            $orcamento = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $orcamento;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }





}

?>
