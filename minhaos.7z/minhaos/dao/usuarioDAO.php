<?php

require_once 'conexao.php';


class UsuarioDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function getAllUsuarios() {
        try {
            $sql = "SELECT u.id, f.nome as nome, u.usuario FROM usuario as u, funcionario as f WHERE u.funcionario_id=f.id  ORDER BY u.id DESC LIMIT 100";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuario;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function salvarUsuario(UsuarioDTO $usuarioDTO) {
        try {
            $sql = "INSERT INTO usuario (funcionario_id,usuario,senha) 
                    VALUES (?,?,?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $usuarioDTO->getFuncionario_id());
            $stmt->bindValue(2, $usuarioDTO->getUsuario());
            $stmt->bindValue(3, $usuarioDTO->getSenha());
            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirUsuario($id) {
        try {
            $sql = "DELETE FROM usuario 
                   WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function updateUsuarioById(UsuarioDTO $usuarioDTO) {
        try {
            $sql = "UPDATE usuario SET senha=?,
                    WHERE id= ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $usuarioDTO->getSenha());
            $stmt->bindValue(2, $usuarioDTO->getId());
            $stmt->execute();
            
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function getUsuarioById($id) {
        try {
            $sql = "SELECT u.id, f.nome as nome, u.usuario FROM usuario as u, funcionario as f  WHERE u.id = ? AND u.funcionario_id=f.id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            return $usuario;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }    


}

?>
