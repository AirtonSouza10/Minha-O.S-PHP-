<?php

require_once 'conexao.php';

class LoginCDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function loginC($usuario,$senha) {
        try {
            $sql = "SELECT * FROM cliente
                    WHERE identificacao=? AND identificacao=?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $usuario);
            $stmt->bindValue(2, $senha);           
            $stmt->execute();
            $loginC = $stmt->fetch(PDO::FETCH_ASSOC);
            return $loginC;
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

}

?>
