<?php

require_once 'conexao.php';


class ClienteDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function getAllClientes() {
        try {
            $sql = "SELECT id,nome,identificacao,telefone,email  FROM cliente ORDER BY id DESC LIMIT 100";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $cliente = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $cliente;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function salvarCliente(ClienteDTO $clienteDTO) {
        try {
            $sql = "INSERT INTO cliente (nome,identificacao,telefone,email) 
                    VALUES (?,?,?,?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $clienteDTO->getNome());
            $stmt->bindValue(2, $clienteDTO->getIdentificacao());
            $stmt->bindValue(3, $clienteDTO->getTelefone());
            $stmt->bindValue(4, $clienteDTO->getEmail());
            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirCliente($id) {
        try {
            $sql = "DELETE FROM cliente 
                   WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function updateClienteById(ClienteDTO $clienteDTO) {
        try {
            $sql = "UPDATE cliente SET     nome=?,
                                           identificacao=?,
                                           telefone=?,
                                           email=?
                    WHERE id= ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $clienteDTO->getNome());
            $stmt->bindValue(2, $clienteDTO->getIdentificacao());
            $stmt->bindValue(3, $clienteDTO->getTelefone());
            $stmt->bindValue(4, $clienteDTO->getEmail());
            $stmt->bindValue(5, $clienteDTO->getId());
            $stmt->execute();
            
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function getClienteById($id) {
        try {
            $sql = "SELECT id,nome,identificacao,telefone,email FROM cliente WHERE id = ? ";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
            return $cliente;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }    


}

?>
