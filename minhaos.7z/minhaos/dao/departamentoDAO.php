<?php

require_once 'conexao.php';


class DepartamentoDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function getAllDepartamentos() {
        try {
            $sql = "SELECT id,departamento 
            FROM departamento ORDER BY id DESC LIMIT 100";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $departamento = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $departamento;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function salvarDepartamento(DepartamentoDTO $departamentoDTO) {
        try {
            $sql = "INSERT INTO departamento (departamento) 
                    VALUES (?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $departamentoDTO->getDepartamento());
            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirDepartamento($id) {
        try {
            $sql = "DELETE FROM departamento 
                   WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function updateDepartamentoById(DepartamentoDTO $departamentoDTO) {
        try {
            $sql = "UPDATE departamento SET departamento=?
                    WHERE id= ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $departamentoDTO->getDepartamento());
            $stmt->bindValue(2, $departamentoDTO->getId());
            $stmt->execute();
            
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function getDepartamentoById($id) {
        try {
            $sql = "SELECT id, departamento FROM departamento WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $departamento = $stmt->fetch(PDO::FETCH_ASSOC);
            return $departamento;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }    


}

?>
