<?php

require_once 'conexao.php';


class FuncionarioDAO {

    public $pdo = null;

    public function __construct() {
        $this->pdo = Conexao::getInstance();
    }

    public function getAllFuncionarios() {
        try {
            $sql = "SELECT f.id,d.departamento as deps,f.nome,f.cpf,f.cargo 
            FROM funcionario as f, departamento as d WHERE f.departamento_id=d.id ORDER BY f.id DESC LIMIT 100";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $funcionario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $funcionario;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function salvarFuncionario(FuncionarioDTO $funcionarioDTO) {
        try {
            $sql = "INSERT INTO funcionario (departamento_id,nome,cpf,cargo) 
                    VALUES (?,?,?,?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $funcionarioDTO->getDepartamento_id());
            $stmt->bindValue(2, $funcionarioDTO->getNome());
            $stmt->bindValue(3, $funcionarioDTO->getCpf());
            $stmt->bindValue(4, $funcionarioDTO->getCargo());
            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirFuncionario($id) {
        try {
            $sql = "DELETE FROM funcionario 
                   WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function updateFuncionarioById(FuncionarioDTO $funcionarioDTO) {
        try {
            $sql = "UPDATE funcionario SET departamento_id=?,
                                           nome=?,
                                           cpf=?,
                                           cargo=?
                    WHERE id= ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $funcionarioDTO->getDepartamento_id());
            $stmt->bindValue(2, $funcionarioDTO->getNome());
            $stmt->bindValue(3, $funcionarioDTO->getCpf());
            $stmt->bindValue(4, $funcionarioDTO->getCargo());
            $stmt->bindValue(5, $funcionarioDTO->getId());
            $stmt->execute();
            
            
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function getFuncionarioById($id) {
        try {
            $sql = "SELECT f.id, f.departamento_id, d.departamento as deps,f.nome,f.cpf,f.cargo FROM funcionario as f, departamento as d WHERE f.id = ? AND f.departamento_id=d.id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $funcionario = $stmt->fetch(PDO::FETCH_ASSOC);
            return $funcionario;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }    


}

?>
