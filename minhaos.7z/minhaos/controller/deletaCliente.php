<?php 

require_once '../dao/clienteDAO.php';

$id = $_GET["id"];
//echo $idfuncionario;

$clienteDAO = new ClienteDAO();
$clienteDAO->excluirCliente($id);
echo "</script>";
echo "<script>";
echo "alert('Excluido com sucesso');";
echo "window.location.href = '../view/cliente.php';";
echo "</script> ";

?>

