<?php
require_once '../dto/usuarioDTO.php';
require_once '../dao/usuarioDAO.php';  

// recuperei os dados do formulario
$senha = $_POST["senha"];
$id = $_POST["id"];

$usuarioDTO = new UsuarioDTO();
$usuarioDTO->setSenha($senha);
$usuarioDTO->setId($id);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM usuario WHERE usuario = '$id'";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0 or mysqli_num_rows($retorno) == 1){ 
$usuarioDAO = new UsuarioDAO();
$usuarioDAO->updateUsuarioById($usuarioDTO);

   echo	"<script>alert('Cadastro alterado com sucesso');</script>";
   echo	"<script>window.location.href = '../view/usuario.php';</script>";

}else{
	echo	"<script>alert('já existe na base de dados');</script>";
	echo	"<script>window.location.href = '../view/usuario.php';</script>";	
}

?>