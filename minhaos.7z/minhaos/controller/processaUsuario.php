<?php
require_once '../dto/usuarioDTO.php';
require_once '../dao/usuarioDAO.php'; 

// recuperei os dados do formulario
$funcionario = $_POST["funcionario"];
$usuario = $_POST["usuario"];
$senha = md5($_POST["senha"]);

$usuarioDTO = new UsuarioDTO();
$usuarioDTO->setFuncionario_id($funcionario);
$usuarioDTO->setUsuario($usuario);
$usuarioDTO->setSenha($senha);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM usuario WHERE usuario = '$usuario' ";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0){ 
$usuarioDAO = new usuarioDAO();
$sucesso = $usuarioDAO->salvarUsuario($usuarioDTO);

if ($sucesso){

   echo	"Cadastro realizado com sucesso";
}
	}
	else{
	echo	"Funcionario já existe na base de dados";

}
?>

