<?php
require_once '../dto/funcionarioDTO.php';
require_once '../dao/funcionarioDAO.php'; 

// recuperei os dados do formulario
$departamento_id = $_POST["departamento"];
$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$cargo = $_POST["cargo"];

$funcionarioDTO = new FuncionarioDTO();
$funcionarioDTO->setDepartamento_id($departamento_id);
$funcionarioDTO->setNome($nome);
$funcionarioDTO->setCpf($cpf);
$funcionarioDTO->setCargo($cargo);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM funcionario WHERE cpf = '$cpf' ";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0){ 
$funcionarioDAO = new funcionarioDAO();
$sucesso = $funcionarioDAO->salvarFuncionario($funcionarioDTO);

if ($sucesso){

   echo	"Cadastro realizado com sucesso";
}
	}
	else{
	echo	"Funcionario já existe na base de dados";

}
?>

