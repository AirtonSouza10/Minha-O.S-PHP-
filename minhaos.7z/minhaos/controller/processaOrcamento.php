<?php
require_once '../dto/orcamentoDTO.php';
require_once '../dao/orcamentoDAO.php'; 

// recuperei os dados do formulario
$cliente = $_POST["cliente"];
$funcionario = $_POST["funcionario"];
$produto = $_POST["produto"];
$datavenda = $_POST["datavenda"];
$dataentrega = $_POST["dataentrega"];
$situacao = $_POST["situacao"];
$os = $_POST["os"];
$obs = $_POST["obs"];

$orcamentoDTO = new OrcamentoDTO();
$orcamentoDTO->setCliente_id($cliente);
$orcamentoDTO->setFuncionario_id($funcionario);
$orcamentoDTO->setProduto($produto);
$orcamentoDTO->setDatavenda($datavenda);
$orcamentoDTO->setDataentrega($dataentrega);
$orcamentoDTO->setSituacao($situacao);
$orcamentoDTO->setOs($os);
$orcamentoDTO->setObs($obs);


$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM orcamento WHERE id = '$produto' ";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0){ 
$orcamentoDAO = new orcamentoDAO();
$sucesso = $orcamentoDAO->salvarOrcamento($orcamentoDTO);

if ($sucesso){

   echo	"Cadastro realizado com sucesso";
}
	}
	else{
	echo	"já existe na base de dados";

}
?>

