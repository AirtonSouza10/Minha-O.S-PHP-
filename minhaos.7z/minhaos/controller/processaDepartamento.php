<?php
require_once '../dto/departamentoDTO.php';
require_once '../dao/departamentoDAO.php'; 

// recuperei os dados do formulario
$departamento = $_POST["departamento"];

$departamentoDTO = new DepartamentoDTO();
$departamentoDTO->setDepartamento($departamento);


$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM departamento WHERE departamento = '$departamento' ";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0){ 
$departamentoDAO = new departamentoDAO();
$sucesso = $departamentoDAO->salvarDepartamento($departamentoDTO);

if ($sucesso){

   echo	"Cadastro realizado com sucesso";
}
	}
	else{
	echo	"Departamento já existe na base de dados";

}
?>

