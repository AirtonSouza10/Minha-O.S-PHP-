<?php
require_once '../dto/funcionarioDTO.php';
require_once '../dao/funcionarioDAO.php';  

// recuperei os dados do formulario
$departamento_id = $_POST["departamento"];
$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$cargo = $_POST["cargo"];
$id = $_POST["id"];

$funcionarioDTO = new FuncionarioDTO();
$funcionarioDTO->setDepartamento_id($departamento_id);
$funcionarioDTO->setNome($nome);
$funcionarioDTO->setCpf($cpf);
$funcionarioDTO->setCargo($cargo);
$funcionarioDTO->setId($id);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM funcionario WHERE cpf = '$cpf'";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0 or mysqli_num_rows($retorno) == 1){ 
$funcionarioDAO = new FuncionarioDAO();
$funcionarioDAO->updateFuncionarioById($funcionarioDTO);

   echo	"<script>alert('Cadastro alterado com sucesso');</script>";
   echo	"<script>window.location.href = '../view/funcionario.php';</script>";

}else{
	echo	"<script>alert('funcionario já existe na base de dados');</script>";
	echo	"<script>window.location.href = '../view/funcionario.php';</script>";	
}

?>