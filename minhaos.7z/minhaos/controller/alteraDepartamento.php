<?php
require_once '../dto/departamentoDTO.php';
require_once '../dao/departamentoDAO.php';  

// recuperei os dados do formulario
$departamento = $_POST["departamento"];
$id = $_POST["id"];

$departamentoDTO = new DepartamentoDTO();
$departamentoDTO->setDepartamento($departamento);
$departamentoDTO->setId($id);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM departamento WHERE departamento = '$departamento'";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0 or mysqli_num_rows($retorno) == 1){ 
$departamentoDAO = new DepartamentoDAO();
$departamentoDAO->updateDepartamentoById($departamentoDTO);

   echo	"<script>alert('Cadastro alterado com sucesso');</script>";
   echo	"<script>window.location.href = '../view/departamento.php';</script>";

}else{
	echo	"<script>alert('departamento já existe na base de dados');</script>";
	echo	"<script>window.location.href = '../view/departamento.php';</script>";	
}

?>