<?php 

require_once '../dao/funcionarioDAO.php';

$id = $_GET["id"];
//echo $idfuncionario;

$funcionarioDAO = new FuncionarioDAO();
$funcionarioDAO->excluirFuncionario($id);
echo "</script>";
echo "<script>";
echo "alert('Excluido com sucesso');";
echo "window.location.href = '../view/funcionario.php';";
echo "</script> ";

?>

