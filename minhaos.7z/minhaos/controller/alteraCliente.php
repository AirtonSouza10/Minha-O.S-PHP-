<?php
require_once '../dto/clienteDTO.php';
require_once '../dao/clienteDAO.php';  

// recuperei os dados do formulario
$nome = $_POST["nome"];
$identificacao = $_POST["identificacao"];
$telefone = $_POST["telefone"];
$email = $_POST["email"];
$id = $_POST["id"];

$clienteDTO = new ClienteDTO();
$clienteDTO->setNome($nome);
$clienteDTO->setIdentificacao($identificacao);
$clienteDTO->setTelefone($telefone);
$clienteDTO->setEmail($email);
$clienteDTO->setId($id);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM cliente WHERE identificacao = '$identificacao
'";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0 or mysqli_num_rows($retorno) == 1){ 
$clienteDAO = new ClienteDAO();
$clienteDAO->updateClienteById($clienteDTO);

   echo	"<script>alert('Cadastro alterado com sucesso');</script>";
   echo	"<script>window.location.href = '../view/cliente.php';</script>";

}else{
	echo	"<script>alert('já existe na base de dados');</script>";
	echo	"<script>window.location.href = '../view/cliente.php';</script>";	
}

?>