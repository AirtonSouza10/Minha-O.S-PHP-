<?php
session_start();
require_once '../dao/loginCDAO.php';

$usuario = $_POST["usuario"];
$senha = ($_POST["senha"]);

$loginCDAO = new LoginCDAO();
$usuario = $loginCDAO->loginC($usuario,$senha);

if (!empty($usuario)) {
    $_SESSION["usuario"] = $_POST["usuario"];

    echo "<script>";
    echo "window.location.href = '../view/principal2.php';";
    echo "</script> ";
} else {
    $msg = "Usuário e/ou senha invalido";
    echo "<script>";
    echo "window.location.href = '../indexc.php?msg={$msg}';";
    echo "</script> ";
    
}
?>