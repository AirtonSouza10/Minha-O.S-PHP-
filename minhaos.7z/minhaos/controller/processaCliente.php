<?php
require_once '../dto/clienteDTO.php';
require_once '../dao/clienteDAO.php'; 

// recuperei os dados do formulario
$nome = $_POST["nome"];
$identificacao = $_POST["identificacao"];
$telefone = $_POST["telefone"];
$email = $_POST["email"];

$clienteDTO = new ClienteDTO();
$clienteDTO->setNome($nome);
$clienteDTO->setIdentificacao($identificacao);
$clienteDTO->setTelefone($telefone);
$clienteDTO->setEmail($email);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM cliente WHERE identificacao = '$identificacao' ";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0){ 
$clienteDAO = new clienteDAO();
$sucesso = $clienteDAO->salvarCliente($clienteDTO);

if ($sucesso){

   echo	"Cadastro realizado com sucesso";
}
	}
	else{
	echo	" já existe na base de dados";

}
?>

