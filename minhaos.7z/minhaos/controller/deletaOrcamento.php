<?php 

require_once '../dao/orcamentoDAO.php';

$id = $_GET["id"];
//echo $idfuncionario;

$orcamentoDAO = new OrcamentoDAO();
$orcamentoDAO->excluirOrcamento($id);
echo "</script>";
echo "<script>";
echo "alert('Excluido com sucesso');";
echo "window.location.href = '../view/orcamento.php';";
echo "</script> ";

?>

