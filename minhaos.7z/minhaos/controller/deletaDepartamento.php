<?php 

require_once '../dao/departamentoDAO.php';

$id = $_GET["id"];
//echo $idfuncionario;

$departamentoDAO = new DepartamentoDAO();
$departamentoDAO->excluirDepartamento($id);
echo "</script>";
echo "<script>";
echo "alert('Excluido com sucesso');";
echo "window.location.href = '../view/departamento.php';";
echo "</script> ";

?>

