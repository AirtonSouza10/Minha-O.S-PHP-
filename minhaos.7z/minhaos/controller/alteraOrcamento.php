<?php
require_once '../dto/orcamentoDTO.php';
require_once '../dao/orcamentoDAO.php';  

// recuperei os dados do formulario
$produto = $_POST["produto"];
$dataentrega = $_POST["dataentrega"];
$situacao = $_POST["situacao"];
$os = $_POST["os"];
$obs = $_POST["obs"];
$id = $_POST["id"];

$orcamentoDTO = new OrcamentoDTO();
$orcamentoDTO->setProduto($produto);
$orcamentoDTO->setDataentrega($dataentrega);
$orcamentoDTO->setSituacao($situacao);
$orcamentoDTO->setOs($os);
$orcamentoDTO->setObs($obs);
$orcamentoDTO->setId($id);

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT * FROM orcamento WHERE id = '$produto'";
$retorno = mysqli_query($conn, $search);

if(mysqli_num_rows($retorno) == 0 or mysqli_num_rows($retorno) == 1){ 
$orcamentoDAO = new OrcamentoDAO();
$orcamentoDAO->updateOrcamentoById($orcamentoDTO);

   echo	"<script>alert('Cadastro alterado com sucesso');</script>";
   echo	"<script>window.location.href = '../view/orcamento.php';</script>";

}else{
	echo	"<script>alert('já existe na base de dados');</script>";
	echo	"<script>window.location.href = '../view/orcamento.php';</script>";	
}

?>