<?php
    session_start();
    include 'validaLogin.php';
    include '../dao/conexao.php';

    $busca = $_POST['busca'];

$conn = mysqli_connect("localhost","root","","orcamento");
$search = "SELECT u.id, f.nome as nome, u.usuario FROM usuario as u, funcionario as f  WHERE u.usuario like '%$busca%' AND u.funcionario_id=f.id ORDER BY u.id desc  limit 50";

$retorno = mysqli_query($conn, $search);
$row_cnt = mysqli_num_rows($retorno);
                      echo "<table class='table table-bordered table-hover table-striped'>";
                      echo "<thead class='thead-dark'>";
                      echo "<tr>";

                      echo  "<th>ID</th>";                   
                      echo  "<th>NOME</th>";
                      echo  "<th>USUARIO</th>";                                   
                      echo  "<th class='actions'>AÇÃO</th>";
                      echo  "</tr>";
                      echo "</thead>";



    if($row_cnt >= 1){ 
        foreach ($retorno as $r) {

                      echo "<tbody>";
                      echo "<tr>";
                      echo "<td>{$r['id']}</td>";
                      echo "<td>{$r['nome']}</td>"; 
                      echo "<td>{$r['usuario']}</td>";  
                      echo "<td>  <a href='../controller/deletaUsuario.php?id={$r["id"]}'><i class='fas fa-trash-alt'></i></a>"; 
                      echo "  <a href='alteraUsuario.php?id={$r["id"]}'><i class='fas fa-edit'></i></a> </td>";                
                      echo "</tr>";
                      echo "</tbody>";
  

                    }

                      echo "</table>";
        
    }
    elseif ($busca = "") {
      echo "conte-nos o que procura";
    }

    else{
        echo "nenhum registro encontrado";
    }
   
?> 