<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- icone -->
    <link rel="icon" href="../imagens/logo.png" type="image/x-icon" />
    <link rel="shortcut icon" href="../imagens/logo.png" type="image/x-icon" />

    <title>Minha O.S.</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
       <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../css/style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


</head>

<body>
        <!--Validacao de usuario logado-->
        <?php
        session_start();
        include 'validaLogin.php';
        include '../dao/conexao.php';
        ?> 
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Minha O.S.</h3>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="principal.php">
                        <i class="fas fa-home"></i>
                        Home
                    </a>
                </li>
                <li>
                    <a href="departamento.php">
                        <i class="fas fa-building"></i>
                        Departamento
                    </a>
                </li>
                <li>
                    <a href="funcionario.php">
                        <i class="fas fa-address-card"></i>
                        Funcionário
                    </a>
                </li>
                <li>
                    <a href="usuario.php">
                        <i class="fas fa-address-book"></i>
                        Usuário
                    </a>
                </li>
                <li>
                    <a href="cliente.php">
                        <i class="fas fa-globe"></i>
                        Cliente
                    </a>
                </li> 
                <li>
                    <a href="orcamento.php">
                        <i class="fas fa-tag"></i>
                        Pedido
                    </a>
                </li>                               
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="../db_bkp/ScriptBKPOticasBrasil.php" class="download">Backup</a>
                </li>
                <li>
                    <a href="logout.php" class="article">Sair</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

             <?php 
                require_once '../dao/usuarioDAO.php';
               
                $id = $_GET["id"];
                $usuarioDAO = new UsuarioDAO();
                $usuario = $usuarioDAO->getUsuarioById($id);   
            ?>           

        <h2>Departamentos</h2>

        <small>Preencha os campos abaixo:</small>
            <div class="form-group col-md-12">
                <div class="form-group col-md-12">

                <form method="post" action="../controller/alteraUsuario.php">
                  <div class="form-row">
                     <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $usuario['id']?>">                    
                      <label>Senha</label>
                      <input type="password" class="form-control" id="senha" placeholder="ex: *****" name="senha" required="required" title="este campo não pode ficar em branco" minlength="2" maxlength="45" autofocus>
                  </div> 
                    </br>
                  <div class="form-row">                                      
                  <button type="submit" class="btn btn-info btn-lg">Salvar</button>
                  </div>
                </form> 
                </div> 
                <!-- Fim divs principais orgao  --> 
            </div> 

        </div>

        </div>
    </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>



    <!-- cadastrar sem refresh de pagina -->    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>  

</body>

</html>