<?php 
class FuncionarioDTO{
	private $id;
	private $departamento_id;
	private $nome;
	private $cpf;
	private $cargo;


	//gets
	public function getId(){
		return $this->id;
	}
	public function getDepartamento_id(){
		return $this->departamento_id;
	}
	public function getNome(){
		return $this->nome;
	}
	public function getCpf(){
		return $this->cpf;
	}
	public function getCargo(){
		return $this->cargo;
	}

	//sets

	public function setId($id){
		$this->id = $id;
	}
	public function setDepartamento_id($departamento_id){
		$this->departamento_id = $departamento_id;
	}
	public function setNome($nome){
		$this->nome=$nome;
	}
	public function setCpf($cpf){
		$this->cpf=$cpf;
	}
	public function setCargo($cargo){
		$this->cargo=$cargo;
	}

}

?>