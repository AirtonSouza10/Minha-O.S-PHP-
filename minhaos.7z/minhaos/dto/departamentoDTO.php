<?php 
class DepartamentoDTO{
	private $id;
	private $departamento;


	//gets
	public function getId(){
		return $this->id;
	}
	public function getDepartamento(){
		return $this->departamento;
	}

	//sets

	public function setId($id){
		$this->id = $id;
	}
	public function setDepartamento($departamento){
		$this->departamento = $departamento;
	}

}

?>