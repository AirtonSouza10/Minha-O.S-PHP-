<?php 
class OrcamentoDTO{
	private $id;
	private $cliente_id;
	private $funcionario_id;
	private $produto;
	private $datavenda;
	private $dataentrega;
	private $situacao;
	private $os;
	private $obs;


	//gets
	public function getId(){
		return $this->id;
	}
	public function getCliente_id(){
		return $this->cliente_id;
	}
	public function getFuncionario_id(){
		return $this->funcionario_id;
	}
	public function getProduto(){
		return $this->produto;
	}
	public function getDatavenda(){
		return $this->datavenda;
	}
	public function getDataEntrega(){
		return $this->dataentrega;
	}
	public function getSituacao(){
		return $this->situacao;
	}
	public function getOs(){
		return $this->os;
	}
	public function getObs(){
		return $this->obs;
	}	



	//sets

	public function setId($id){
		$this->id = $id;
	}
	public function setCliente_id($cliente_id){
		$this->cliente_id = $cliente_id;
	}
	public function setFuncionario_id($funcionario_id){
		$this->funcionario_id=$funcionario_id;
	}
	public function setProduto($produto){
		$this->produto=$produto;
	}
	public function setDatavenda($datavenda){
		$this->datavenda=$datavenda;
	}
	public function setDataentrega($dataentrega){
		$this->dataentrega=$dataentrega;
	}	
	public function setSituacao($situacao){
		$this->situacao=$situacao;
	}
	public function setOs($os){
		$this->os=$os;
	}	
	public function setObs($obs){
		$this->obs=$obs;
	}			

}

?>