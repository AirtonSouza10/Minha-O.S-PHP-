<?php 
class UsuarioDTO{

    private $funcionario_id;
    private $usuario;
    private $senha;
    //gets

    public function getFuncionario_id() {
        return $this->funcionario_id;
    }

    public function getUsuario(){
    	return $this->usuario;
    }

    public function getSenha(){
    	return $this->senha;
    }
    //sets

    public function setFuncionario_id($funcionario_id) {
        $this->funcionario_id = $funcionario_id;
    }

    public function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    public function setSenha($senha) {
        $this->senha = $senha;
    } 

}

?>