<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- icone -->
    <link rel="icon" href="imagens/logo.png" type="image/x-icon" />
    <link rel="shortcut icon" href="imagens/logo.png" type="image/x-icon" />

    <title>Minha O.S.</title>
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.mask.min.js"></script>
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/estilo.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

</head>

<body>

    <div class="flex-box container-box">
      
      <div class="content-box">

        <img src="imagens/logo.png" width="100px" height="70px">
        <h3>Minha O.S.</h3>
        <small>Digite abaixo seus dados de acesso</small>
        <br/>
        <br/>

        <!--################################################################-->
        <form method="POST" action="controller/loginControllerC.php">
          <div class="form-group">
            <label>Usuário</label>
            <input type="text" class="form-control-sm" name="usuario" aria-describedby="usuario" placeholder="seu nome de usuário">
          </div>
          <div class="form-group">
            <label >Senha </label>
            <input type="password" class="form-control-sm" name="senha" placeholder="Senha">
          </div>
          <button type="submit" class="btn btn-primary">Logar</button>
          <button type="reset" class="btn btn-primary">Limpar</button>
          <button type="button" class="btn btn-info" onClick="history.go(-1)"> Voltar</button>
        </form>


      </div>
    </div>

    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

</body>

</html>