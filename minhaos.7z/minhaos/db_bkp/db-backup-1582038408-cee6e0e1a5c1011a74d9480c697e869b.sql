DROP TABLE IF EXISTS cliente;

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `identificacao` varchar(14) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO cliente VALUES("6","Astolfo Minerador de Oliveira","36925478414","61995458970","astolfo@gmail.com");
INSERT INTO cliente VALUES("5","Consumidor final","12345678910","61992455577","teste@gmail.com");



DROP TABLE IF EXISTS departamento;

CREATE TABLE `departamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departamento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO departamento VALUES("1","TECNOLOGIA");
INSERT INTO departamento VALUES("8","FINANCEIRO");
INSERT INTO departamento VALUES("7","ESTOQUE");



DROP TABLE IF EXISTS funcionario;

CREATE TABLE `funcionario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departamento_id` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `cargo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`departamento_id`),
  KEY `Funcionario_FKIndex1` (`departamento_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO funcionario VALUES("7","8","Joquebede","65459988777","teste@gmail.com");
INSERT INTO funcionario VALUES("5","1","Admin","12345678910","Administrador");



DROP TABLE IF EXISTS orcamento;

CREATE TABLE `orcamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `Funcionario_id` int(11) NOT NULL,
  `produto` varchar(100) NOT NULL,
  `dataVenda` date NOT NULL,
  `dataEntrega` date NOT NULL,
  `situacao` varchar(45) NOT NULL,
  `os` int(11) NOT NULL,
  `obs` varchar(100) NOT NULL,
  PRIMARY KEY (`id`,`cliente_id`,`Funcionario_id`),
  KEY `orcamento_FKIndex1` (`cliente_id`),
  KEY `orcamento_FKIndex2` (`Funcionario_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO orcamento VALUES("9","5","5","teste","2020-02-18","2020-02-27","Em laborat�rio","787878","teste de cliente");
INSERT INTO orcamento VALUES("8","6","7","NATURAL VISION","2020-02-18","2020-02-29","Em laborat�rio","8547","Cliente viaja dia 27/02, agilizar processo de fabrica��o.
segunda os. liberar junto com a anerior
");
INSERT INTO orcamento VALUES("7","6","7","POLY AR","2020-02-18","2020-02-27","Em laborat�rio","1598","Cliente viaja dia 27/02, agilizar processo de fabrica��o.
");



DROP TABLE IF EXISTS usuario;

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Funcionario_id` int(11) NOT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`Funcionario_id`),
  KEY `usuario_FKIndex1` (`Funcionario_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO usuario VALUES("7","7","joque","202cb962ac59075b964b07152d234b70");
INSERT INTO usuario VALUES("4","5","admin","202cb962ac59075b964b07152d234b70");



